(() => {
  'use strict';
  const quick = document.getElementById('variant-idea-form');
  if (quick) quick.addEventListener('submit', event => event.preventDefault());
  document.getElementById('variant-continue')?.addEventListener('click', () => {
    const recipient = document.getElementById('variant-recipient').value;
    const hobby = document.getElementById('variant-hobby').value.trim();
    document.getElementById('idea').value = `Подарок: ${recipient}${hobby ? '. Увлечение: ' + hobby : ''}`;
    document.getElementById('quote').scrollIntoView({block: 'start'});
  });
  document.querySelectorAll('.kh-section-cta a').forEach(link => {
    link.addEventListener('click', () => {
      const select = document.getElementById('product_type');
      const id = link.closest('section')?.id;
      if (select && Array.from(select.options).some(option => option.value === id)) select.value = id;
    });
  });
})();
