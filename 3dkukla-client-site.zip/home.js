/* Local interactions only. No CRM, tracking payloads, network requests or success simulation. */
(() => {
  'use strict';
  const toggle = document.querySelector('.kh-menu-toggle');
  const nav = document.getElementById('kh-nav');
  if (toggle && nav) {
    toggle.hidden = false;
    const close = () => {
      toggle.setAttribute('aria-expanded', 'false');
      nav.classList.remove('is-open');
    };
    toggle.addEventListener('click', () => {
      const open = toggle.getAttribute('aria-expanded') !== 'true';
      toggle.setAttribute('aria-expanded', String(open));
      nav.classList.toggle('is-open', open);
    });
    nav.addEventListener('click', (event) => {
      if (event.target.closest('a')) close();
    });
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && nav.classList.contains('is-open')) {
        close(); toggle.focus();
      }
    });
  }
  const method = document.getElementById('contact_method');
  const dialog = document.getElementById('kh-lightbox');
  if (dialog && typeof dialog.showModal === 'function') {
    const view = dialog.querySelector('.kh-lightbox-view');
    document.querySelectorAll('[data-full-image]').forEach(button => {
      button.addEventListener('click', () => {
        const image = new Image();
        image.src = button.dataset.fullImage;
        image.alt = button.querySelector('img')?.alt || 'Изображение фигурки';
        view.replaceChildren(image);
        dialog.showModal();
      });
    });
    dialog.querySelector('.kh-lightbox-close').addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  }
  document.querySelectorAll('.kh-video video').forEach(video => {
    video.addEventListener('play', () => {
      document.querySelectorAll('.kh-video video').forEach(other => { if (other !== video) other.pause(); });
    });
  });
  const contact = document.getElementById('quote-contact');
  if (method && contact) {
    method.addEventListener('change', () => {
      contact.type = method.value === 'email' ? 'email' : 'tel';
      contact.autocomplete = contact.type;
    });
  }
  // Product choices remain in the browser. Nothing is transmitted or persisted.
  document.querySelectorAll('.kh-section-cta a[href="#quote"], .kh-section-cta a[href="./#quote"]').forEach((link) => {
    link.addEventListener('click', () => {
      const select = document.getElementById('product_type');
      const id = link.closest('section')?.id;
      if (select && Array.from(select.options).some((option) => option.value === id)) {
        select.value = id;
      }
    });
  });
})();
